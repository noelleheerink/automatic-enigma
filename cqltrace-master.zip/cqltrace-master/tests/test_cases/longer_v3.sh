#!/bin/bash
./cqltrace -b -k $1
