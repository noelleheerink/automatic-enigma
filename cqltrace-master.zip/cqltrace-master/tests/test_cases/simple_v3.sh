#!/bin/bash
./cqltrace -b $1
